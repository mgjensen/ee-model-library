# assembly/engine.py
